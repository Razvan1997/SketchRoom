﻿using SketchRoom.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WhiteBoard.Core.Services.Interfaces;
using WhiteBoard.Core.Tools;

namespace SketchRoom.Toolkit.Wpf.Controls
{
    /// <summary>
    /// Interaction logic for TextElementControl.xaml
    /// </summary>
    public partial class TextElementControl : UserControl, ITextInteractiveShape
    {
        private bool _isDragging = false;
        private Point _dragStart;
        private bool _isRotating = false;
        private Point _rotateStart;
        private bool _isTextEditing = false;

        public TextElementControl()
        {
            InitializeComponent();
            this.Cursor = Cursors.IBeam;

            EditableText.GotFocus += (s, e) => _isTextEditing = true;
            EditableText.LostFocus += (s, e) => _isTextEditing = false;

            RotateIcon.PreviewMouseLeftButtonDown += RotateIcon_PreviewMouseLeftButtonDown;
            RotateIcon.PreviewMouseLeftButtonUp += RotateIcon_PreviewMouseLeftButtonUp;
            RotateIcon.PreviewMouseMove += RotateIcon_PreviewMouseMove;
        }

        public UIElement Visual => this;
        public bool EnableConnectors { get; set; } = false;
        public event MouseButtonEventHandler? ShapeClicked;
        public event EventHandler<string>? ConnectionPointClicked;
        public event EventHandler? ConnectionRequested;

        public void SetShape(ShapeType shape)
        {
            if (shape == ShapeType.TextInput)
            {
                EditableText.FontFamily = new FontFamily("Segoe UI");
                EditableText.FontSize = 14;
                EditableText.Foreground = Brushes.Black;
            }
        }

        public void SetPosition(Point position)
        {
            Canvas.SetLeft(this, position.X);
            Canvas.SetTop(this, position.Y);
        }

        public void Select()
        {
            RotateIcon.Visibility = Visibility.Visible;
            EditableText.Focus();
            EditableText.SelectAll();
        }

        public void Deselect()
        {
            RotateIcon.Visibility = Visibility.Collapsed;
        }

        public void FocusText()
        {
            EditableText.Focus();
            EditableText.SelectAll();
        }

        public string Text
        {
            get => EditableText.Text;
            set => EditableText.Text = value;
        }

        private void RotateIcon_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var toolManager = ContainerLocator.Container.Resolve<IToolManager>();
            var canvas = VisualTreeHelper.GetParent(this) as Canvas;

            if (canvas != null && toolManager.GetToolByName("RotateTool") is RotateTool rt)
            {
                _isRotating = true;
                _rotateStart = e.GetPosition(canvas);
                rt.StartRotation(this, _rotateStart);
                toolManager.SetActive("RotateTool");
                e.Handled = true;
            }
        }

        private void RotateIcon_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (!_isRotating) return;

            var canvas = VisualTreeHelper.GetParent(this) as Canvas;
            var toolManager = ContainerLocator.Container.Resolve<IToolManager>();
            if (canvas != null && toolManager.ActiveTool is RotateTool rt)
            {
                Point pos = e.GetPosition(canvas);
                rt.OnMouseMove(pos);
            }
        }

        private void RotateIcon_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            var canvas = VisualTreeHelper.GetParent(this) as Canvas;
            var toolManager = ContainerLocator.Container.Resolve<IToolManager>();

            if (canvas != null && _isRotating && toolManager.ActiveTool is RotateTool rt)
            {
                rt.OnMouseUp(e.GetPosition(canvas));
                toolManager.SetActive("BpmnTool");
                _isRotating = false;
                e.Handled = true;
            }
        }

        private void EditableText_TextChanged(object sender, TextChangedEventArgs e)
        {
            EditableText.Height = Double.NaN;
            EditableText.UpdateLayout();
            MainGrid.UpdateLayout();

            this.Width = EditableText.ActualWidth;
            this.Height = EditableText.ActualHeight + 10;
        }
    }
}
