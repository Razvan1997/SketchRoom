﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WhiteBoard.Core.Services.Interfaces
{
    public interface ITextSelectableShape : IUpdateStyle
    {
        IEnumerable<RichTextBox> GetEditableRichTextBoxes();
    }
}
