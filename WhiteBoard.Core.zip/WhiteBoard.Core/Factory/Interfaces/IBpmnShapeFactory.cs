﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace WhiteBoard.Core.Factory.Interfaces
{
    public interface IBpmnShapeFactory
    {
        UIElement CreateShape(Uri svgUri);
    }
}
